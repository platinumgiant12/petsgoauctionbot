import discord
from discord import app_commands
from discord.ext import commands
import asyncio
import os

# --- BOT CONFIG ---
TOKEN = os.getenv("TOKEN") or "MTQyOTk2MTI2MzgxOTAwMTkxNw.G48aZm.P0oyKJH7oSuP5Z8AOfI1AOLDHQ7G_49MJLjpDc"
GUILD_ID = 1429941074041897052

# --- BASIC SETUP ---
intents = discord.Intents.default()
intents.message_content = False
bot = commands.Bot(command_prefix="/", intents=intents)
tree = bot.tree

# ====== AUCTION CLASS ======
class Auction:
    def __init__(self, interaction, item_name, tier, start_bid, category):
        self.interaction = interaction
        self.item_name = item_name
        self.tier = tier
        self.category = category
        self.current_bid = start_bid
        self.highest_bidder = None
        self.active = True
        self.timer = 60
        self.message = None

    def create_embed(self):
        """Create the auction embed"""
        embed = discord.Embed(
            title="🚨 Pets GO Auction 🚨",
            color=discord.Color.gold(),
            timestamp=discord.utils.utcnow()
        )
        
        embed.add_field(name="📦 Item", value=f"**{self.item_name}**", inline=True)
        embed.add_field(name="🏆 Tier", value=f"**{self.tier}**", inline=True)
        embed.add_field(name="📂 Category", value=f"**{self.category}**", inline=True)
        
        embed.add_field(
            name="💎 Current Bid",
            value=f"**{self.current_bid:,} Gems**",
            inline=True
        )
        
        bidder_text = self.highest_bidder.mention if self.highest_bidder else "No bids yet"
        embed.add_field(
            name="👤 Highest Bidder",
            value=bidder_text,
            inline=True
        )
        
        # Timer with color coding
        if self.timer > 15:
            timer_emoji = "⏰"
        else:
            timer_emoji = "🔥"
        
        embed.add_field(
            name=f"{timer_emoji} Time Remaining",
            value=f"**{self.timer}s**",
            inline=True
        )
        
        embed.set_footer(text="💡 Use /bid <amount> to place your bid!")
        
        return embed

    async def run(self):
        """Run the auction timer loop"""
        channel = self.interaction.channel
        
        # Send initial embed
        embed = self.create_embed()
        self.message = await channel.send(embed=embed)
        
        # Countdown loop - update every 5 seconds or when under 15s
        last_update = self.timer
        
        while self.timer > 0 and self.active:
            await asyncio.sleep(1)
            self.timer -= 1
            
            # Update embed every 5 seconds or when under 15 seconds
            should_update = (
                (self.timer % 5 == 0) or 
                (self.timer <= 15) or
                (self.timer == 0)
            )
            
            if should_update and self.timer != last_update:
                try:
                    embed = self.create_embed()
                    await self.message.edit(embed=embed)
                    last_update = self.timer
                except Exception:
                    pass
        
        # End auction
        if self.active:
            await self.end_auction()
    
    async def end_auction(self):
        """End the auction and announce winner"""
        self.active = False
        
        embed = discord.Embed(
            title="🏁 Auction Ended! 🏁",
            color=discord.Color.red(),
            timestamp=discord.utils.utcnow()
        )
        
        embed.add_field(name="📦 Item", value=f"**{self.item_name}**", inline=True)
        embed.add_field(name="🏆 Tier", value=f"**{self.tier}**", inline=True)
        embed.add_field(name="📂 Category", value=f"**{self.category}**", inline=True)
        
        if self.highest_bidder:
            embed.add_field(
                name="🎉 Winner",
                value=self.highest_bidder.mention,
                inline=False
            )
            embed.add_field(
                name="💎 Winning Bid",
                value=f"**{self.current_bid:,} Gems**",
                inline=False
            )
            embed.set_footer(text="🎟️ Please open a Ticket Tool ticket to verify your Gems and claim your item!")
        else:
            embed.description = "⏰ **No bids were placed**"
            embed.color = discord.Color.orange()
        
        if self.message:
            await self.message.edit(embed=embed)
        else:
            await self.interaction.channel.send(embed=embed)

# ====== ACTIVE AUCTIONS ======
active_auctions = {}

# ====== COMMANDS ======
@tree.command(name="startauction", description="Start a Pets GO auction")
@app_commands.describe(
    category="Select the category (Pets or Misc)",
    tier="Select the tier",
    item_name="Name of the item being auctioned",
    start_bid="Starting bid amount in Gems"
)
@app_commands.choices(category=[
    app_commands.Choice(name="Pets", value="Pets"),
    app_commands.Choice(name="Misc", value="Misc")
])
@app_commands.choices(tier=[
    app_commands.Choice(name="Exclusive", value="Exclusive"),
    app_commands.Choice(name="Huge", value="Huge"),
    app_commands.Choice(name="Titanic", value="Titanic"),
    app_commands.Choice(name="Exotic", value="Exotic"),
    app_commands.Choice(name="Divine", value="Divine"),
    app_commands.Choice(name="Superior", value="Superior"),
    app_commands.Choice(name="Celestial", value="Celestial")
])
async def startauction(interaction: discord.Interaction, category: app_commands.Choice[str], tier: app_commands.Choice[str], item_name: str, start_bid: int):
    if not interaction.channel:
        await interaction.response.send_message("❌ This command can only be used in a server channel.", ephemeral=True)
        return
    
    if interaction.channel.id in active_auctions:
        await interaction.response.send_message("❌ An auction is already running in this channel.", ephemeral=True)
        return
    
    # Validate tier for category
    pets_tiers = ["Exclusive", "Huge", "Titanic"]
    misc_tiers = ["Exotic", "Divine", "Superior", "Celestial", "Exclusive"]
    
    if category.value == "Pets" and tier.value not in pets_tiers:
        await interaction.response.send_message(f"❌ Invalid tier for Pets. Valid tiers: {', '.join(pets_tiers)}", ephemeral=True)
        return
    
    if category.value == "Misc" and tier.value not in misc_tiers:
        await interaction.response.send_message(f"❌ Invalid tier for Misc. Valid tiers: {', '.join(misc_tiers)}", ephemeral=True)
        return

    auction = Auction(interaction, item_name, tier.value, start_bid, category.value)
    active_auctions[interaction.channel.id] = auction
    await interaction.response.send_message(f"✅ Auction for **{item_name}** ({tier.value}) started!", ephemeral=True)
    await auction.run()
    if interaction.channel.id in active_auctions:
        del active_auctions[interaction.channel.id]

@tree.command(name="bid", description="Place a bid on the current auction")
@app_commands.describe(amount="The amount of Gems you want to bid (must be higher than current bid)")
async def bid(interaction: discord.Interaction, amount: int):
    if not interaction.channel:
        await interaction.response.send_message("❌ This command can only be used in a server channel.", ephemeral=True)
        return
    
    auction = active_auctions.get(interaction.channel.id)
    if not auction or not auction.active:
        await interaction.response.send_message("❌ No active auction in this channel.", ephemeral=True)
        return

    if amount <= auction.current_bid:
        await interaction.response.send_message("⚠️ Your bid must be **higher** than the current bid.", ephemeral=True)
        return

    auction.current_bid = amount
    auction.highest_bidder = interaction.user

    # Anti-snipe: Reset timer to 15s if bid made when timer is at 15s or lower
    snipe_message = ""
    if auction.timer <= 15:
        auction.timer = 15
        snipe_message = "\n🔥 **Anti-snipe activated!** Timer reset to 15s!"
    
    # Update the embed immediately
    try:
        embed = auction.create_embed()
        await auction.message.edit(embed=embed)
    except Exception:
        pass

    await interaction.response.send_message(
        f"💎 {interaction.user.mention} placed a bid of **{amount:,}** Gems!{snipe_message}",
        ephemeral=False
    )

@tree.command(name="cancelauction", description="Cancel the current auction (only the host can do this)")
async def cancelauction(interaction: discord.Interaction):
    if not interaction.channel:
        await interaction.response.send_message("❌ This command can only be used in a server channel.", ephemeral=True)
        return
    
    auction = active_auctions.get(interaction.channel.id)
    if not auction:
        await interaction.response.send_message("❌ No active auction to cancel.", ephemeral=True)
        return

    if auction.interaction.user.id != interaction.user.id:
        await interaction.response.send_message("⚠️ Only the auction starter can cancel this.", ephemeral=True)
        return

    auction.active = False
    await interaction.response.send_message("🚫 Auction cancelled.")
    await auction.interaction.channel.send("❌ The auction has been cancelled by the host.")

# ====== STARTUP ======
@bot.event
async def on_ready():
    print(f"✅ Logged in as {bot.user}")
    print(f"📋 Bot is in {len(bot.guilds)} server(s)")
    
    try:
        # Sync globally - this will override ALL old commands everywhere
        print("🔄 Syncing commands globally (this will fix the signature mismatch)...")
        synced = await tree.sync()
        print(f"✅ Synced {len(synced)} commands globally!")
        
        if len(synced) > 0:
            print(f"   Commands: {', '.join([cmd.name for cmd in synced])}")
            print("   ⏳ Commands will appear in Discord within a few minutes (up to 1 hour)")
            print("   💡 Try typing / in your server now - they might already be there!")
        else:
            print("⚠️  WARNING: 0 commands synced!")
    except Exception as e:
        print(f"❌ Error syncing commands: {e}")
        import traceback
        traceback.print_exc()

bot.run(TOKEN)